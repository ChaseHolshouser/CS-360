package com.example.project2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editItemQuantity;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Connect the input fields and buttons.
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);

        Button saveItem = findViewById(R.id.btnSaveItem);
        Button cancelItem = findViewById(R.id.btnCancelItem);

        databaseHelper = new DatabaseHelper(this);

        // Save a new item to the SQLite database.
        saveItem.setOnClickListener(v -> saveInventoryItem());

        // Return without saving.
        cancelItem.setOnClickListener(v -> finish());
    }

    private void saveInventoryItem() {

        String itemName = editItemName.getText()
                .toString().trim();

        String quantityText = editItemQuantity.getText()
                .toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter an item name and quantity.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    "Please enter a valid quantity.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (quantity < 0) {
            Toast.makeText(
                    this,
                    "Quantity cannot be negative.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Insert the item into the inventory table.
        boolean saved = databaseHelper.addItem(
                itemName,
                quantity
        );

        if (saved) {
            Toast.makeText(
                    this,
                    "Item added successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {
            Toast.makeText(
                    this,
                    "Unable to save item.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}
