package com.example.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryManagement.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory";

    private static final int HASH_ITERATIONS = 120000;
    private static final int KEY_LENGTH = 256;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store login credentials separately from inventory items.
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash BLOB NOT NULL, " +
                        "password_salt BLOB NOT NULL)"
        );

        // Store each inventory item's name and quantity.
        db.execSQL(
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "item_name TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL DEFAULT 0 " +
                        "CHECK(quantity >= 0))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {

        // Future database schema migrations belong here.
        // Version 1 does not require any upgrades.
    }

    // Create a user account with a salted password hash.
    public boolean createUser(String username, String password) {

        username = username.trim();

        if (username.isEmpty() || password.isEmpty()) {
            return false;
        }

        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);

            byte[] hash = hashPassword(password, salt);

            ContentValues values = new ContentValues();
            values.put("username", username);
            values.put("password_hash", hash);
            values.put("password_salt", salt);

            long result = getWritableDatabase().insert(
                    TABLE_USERS, null, values
            );

            return result != -1;

        } catch (Exception e) {
            return false;
        }
    }

    // Verify the username and password against SQLite.
    public boolean checkLogin(String username, String password) {

        username = username.trim();

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"password_hash", "password_salt"},
                "username = ?",
                new String[]{username},
                null, null, null
        )) {

            if (!cursor.moveToFirst()) {
                return false;
            }

            byte[] storedHash = cursor.getBlob(0);
            byte[] salt = cursor.getBlob(1);
            byte[] enteredHash = hashPassword(password, salt);

            return MessageDigest.isEqual(storedHash, enteredHash);

        } catch (Exception e) {
            return false;
        }
    }

    // Add a new inventory item.
    public boolean addItem(String name, int quantity) {

        if (name.trim().isEmpty() || quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("item_name", name.trim());
        values.put("quantity", quantity);

        return getWritableDatabase().insert(
                TABLE_INVENTORY, null, values
        ) != -1;
    }

    // Retrieve all saved inventory items.
    // The activity will use this cursor to build the grid.
    public Cursor getAllItems() {

        return getReadableDatabase().query(
                TABLE_INVENTORY,
                new String[]{"id", "item_name", "quantity"},
                null, null, null, null,
                "item_name COLLATE NOCASE ASC"
        );
    }

    // Update the quantity of one inventory item.
    public boolean updateQuantity(int itemId, int quantity) {

        if (quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put("quantity", quantity);

        return getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id = ?",
                new String[]{String.valueOf(itemId)}
        ) > 0;
    }

    // Permanently delete an inventory item.
    public boolean deleteItem(int itemId) {

        return getWritableDatabase().delete(
                TABLE_INVENTORY,
                "id = ?",
                new String[]{String.valueOf(itemId)}
        ) > 0;
    }

    // Use PBKDF2 so passwords are not stored as plain text.
    private byte[] hashPassword(String password, byte[] salt)
            throws Exception {

        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(),
                salt,
                HASH_ITERATIONS,
                KEY_LENGTH
        );

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            return factory.generateSecret(spec).getEncoded();

        } finally {
            spec.clearPassword();
        }
    }
}
