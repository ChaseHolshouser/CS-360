package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect the login screen to its XML components.
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        Button login = findViewById(R.id.buttonLogin);
        Button createAccount =
                findViewById(R.id.buttonCreateAccount);

        // Open the SQLite database.
        databaseHelper = new DatabaseHelper(this);

        // Validate an existing user's credentials.
        login.setOnClickListener(v -> loginUser());

        // Create and save a new user account.
        createAccount.setOnClickListener(v -> createUser());
    }

    private void loginUser() {

        String username = editUsername.getText()
                .toString().trim();

        String password = editPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (databaseHelper.checkLogin(username, password)) {

            Toast.makeText(
                    this,
                    "Login successful!",
                    Toast.LENGTH_SHORT
            ).show();

            openInventory();

        } else {

            Toast.makeText(
                    this,
                    "Invalid username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void createUser() {

        String username = editUsername.getText()
                .toString().trim();

        String password = editPassword.getText()
                .toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (password.length() < 8) {
            Toast.makeText(
                    this,
                    "Password must be at least 8 characters.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        boolean created =
                databaseHelper.createUser(username, password);

        if (created) {

            Toast.makeText(
                    this,
                    "Account created successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            openInventory();

        } else {

            Toast.makeText(
                    this,
                    "Unable to create account. Username may already exist.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void openInventory() {

        Intent intent = new Intent(
                this,
                InventoryActivity.class
        );

        startActivity(intent);
        finish();
    }
}
