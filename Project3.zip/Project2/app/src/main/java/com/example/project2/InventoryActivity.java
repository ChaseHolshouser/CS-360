package com.example.project2;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TableLayout tableInventory;
    private TextView textEmptyInventory;
    private TextView textLowStock;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        preferences = getSharedPreferences(
                "InventorySettings",
                MODE_PRIVATE
        );

        tableInventory = findViewById(R.id.tableInventory);
        textEmptyInventory = findViewById(R.id.textEmptyInventory);
        textLowStock = findViewById(R.id.textLowStock);

        Button addItem = findViewById(R.id.btnAddItem);
        Button smsSettings = findViewById(R.id.btnSmsSettings);

        addItem.setOnClickListener(v ->
                startActivity(new Intent(
                        this, AddItemActivity.class
                ))
        );

        smsSettings.setOnClickListener(v ->
                startActivity(new Intent(
                        this, SmsSettingsActivity.class
                ))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        displayInventory();
    }

    // Read SQLite records and rebuild the inventory grid.
    private void displayInventory() {

        int rowCount = tableInventory.getChildCount();

        if (rowCount > 1) {
            tableInventory.removeViews(1, rowCount - 1);
        }

        int itemCount = 0;
        int outOfStockCount = 0;

        try (Cursor cursor = databaseHelper.getAllItems()) {

            while (cursor.moveToNext()) {

                int itemId = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int quantity = cursor.getInt(2);

                addInventoryRow(itemId, itemName, quantity);
                itemCount++;

                if (quantity == 0) {
                    outOfStockCount++;
                }
            }
        }

        textEmptyInventory.setVisibility(
                itemCount == 0 ? View.VISIBLE : View.GONE
        );

        if (outOfStockCount > 0) {

            textLowStock.setText(
                    "Low Stock Alert: " + outOfStockCount
                            + " item(s) out of stock."
            );

            textLowStock.setVisibility(View.VISIBLE);

        } else {
            textLowStock.setVisibility(View.GONE);
        }
    }

    private void addInventoryRow(
            int itemId, String itemName, int quantity) {

        TableRow row = new TableRow(this);
        row.setPadding(8, 10, 8, 10);
        row.setBackgroundColor(
                Color.parseColor("#F7F3E9")
        );

        TextView nameView = new TextView(this);
        nameView.setText(itemName);
        nameView.setTextColor(
                Color.parseColor("#3D3027")
        );
        nameView.setTextSize(15);
        nameView.setPadding(8, 12, 8, 12);
        nameView.setWidth(dp(130));
        row.addView(nameView);

        TextView quantityView = new TextView(this);
        quantityView.setText(String.valueOf(quantity));
        quantityView.setTextColor(
                quantity == 0
                        ? Color.RED
                        : Color.parseColor("#3D3027")
        );
        quantityView.setTextSize(16);
        quantityView.setGravity(Gravity.CENTER);
        quantityView.setWidth(dp(55));
        row.addView(quantityView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);

        TextView decrease = createActionButton("−");
        TextView increase = createActionButton("+");
        TextView delete = createActionButton("Delete");

        // Decrease quantity without allowing negative stock.
        decrease.setOnClickListener(v -> {

            if (quantity > 0) {

                int newQuantity = quantity - 1;

                boolean updated = databaseHelper.updateQuantity(
                        itemId, newQuantity
                );

                if (updated) {

                    // Alert only when stock transitions to zero.
                    if (newQuantity == 0) {
                        sendLowStockAlert(itemName);
                    }

                    displayInventory();
                }
            }
        });

        // Increase quantity.
        increase.setOnClickListener(v -> {

            if (quantity == Integer.MAX_VALUE) {
                Toast.makeText(
                        this,
                        "Maximum quantity reached.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            boolean updated = databaseHelper.updateQuantity(
                    itemId, quantity + 1
            );

            if (updated) {
                displayInventory();
            }
        });

        // Delete inventory item.
        delete.setOnClickListener(v -> {

            boolean deleted = databaseHelper.deleteItem(itemId);

            if (deleted) {

                Toast.makeText(
                        this,
                        "Item deleted.",
                        Toast.LENGTH_SHORT
                ).show();

                displayInventory();
            }
        });

        actions.addView(decrease);
        actions.addView(increase);
        actions.addView(delete);

        row.addView(actions);
        tableInventory.addView(row);
    }

    private TextView createActionButton(String label) {

        TextView button = new TextView(this);

        button.setText(label);
        button.setTextColor(
                Color.parseColor("#3D3027")
        );
        button.setTextSize(
                label.equals("Delete") ? 13 : 22
        );
        button.setGravity(Gravity.CENTER);
        button.setBackgroundColor(
                Color.parseColor("#A8B49A")
        );
        button.setClickable(true);
        button.setFocusable(true);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        label.equals("Delete") ? dp(75) : dp(44),
                        dp(44)
                );

        params.setMargins(
                dp(3), dp(3), dp(3), dp(3)
        );

        button.setLayoutParams(params);

        return button;
    }

    // Send an SMS only when alerts are enabled and permitted.
    private void sendLowStockAlert(String itemName) {

        boolean enabled = preferences.getBoolean(
                "sms_enabled", false
        );

        String phoneNumber = preferences.getString(
                "phone_number", ""
        );

        boolean hasPermission =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (!enabled || !hasPermission ||
                phoneNumber.isEmpty()) {

            // SMS is optional. Inventory still works.
            return;
        }

        String message =
                "Inventory Alert: " + itemName
                        + " is out of stock. "
                        + "Please restock this item.";

        try {

            SmsManager smsManager;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

                smsManager = getSystemService(
                        SmsManager.class
                );

            } else {

                smsManager = SmsManager.getDefault();
            }

            if (smsManager == null) {
                throw new IllegalStateException(
                        "SMS service unavailable."
                );
            }

            // Divide long messages into SMS-sized segments.
            java.util.ArrayList<String> parts =
                    smsManager.divideMessage(message);

            smsManager.sendMultipartTextMessage(
                    phoneNumber,
                    null,
                    parts,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    "Out-of-stock SMS submitted.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "SMS could not be sent. Inventory was updated.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private int dp(int value) {

        return Math.round(
                value * getResources()
                        .getDisplayMetrics().density
        );
    }
}
