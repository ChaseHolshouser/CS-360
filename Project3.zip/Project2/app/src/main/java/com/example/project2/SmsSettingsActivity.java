package com.example.project2;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsSettingsActivity extends AppCompatActivity {

    private EditText editPhoneNumber;
    private TextView textSmsStatus;
    private SharedPreferences preferences;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            preferences.edit()
                                    .putBoolean("sms_enabled", true)
                                    .apply();

                            Toast.makeText(
                                    this,
                                    "SMS alerts enabled!",
                                    Toast.LENGTH_SHORT
                            ).show();
                        } else {
                            preferences.edit()
                                    .putBoolean("sms_enabled", false)
                                    .apply();

                            Toast.makeText(
                                    this,
                                    "Permission denied. Inventory still works.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }

                        updateSmsStatus();
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        textSmsStatus = findViewById(R.id.textSmsStatus);

        Button enableSms = findViewById(R.id.btnEnableSms);
        Button notNow = findViewById(R.id.btnSkipSms);

        preferences = getSharedPreferences(
                "InventorySettings",
                MODE_PRIVATE
        );

        // Restore the saved phone number.
        String savedNumber = preferences.getString(
                "phone_number", ""
        );

        editPhoneNumber.setText(savedNumber);

        updateSmsStatus();

        enableSms.setOnClickListener(v -> enableSmsAlerts());

        notNow.setOnClickListener(v -> finish());
    }

    private void enableSmsAlerts() {

        String phoneNumber = editPhoneNumber.getText()
                .toString().trim();

        if (phoneNumber.isEmpty() ||
                !PhoneNumberUtils.isGlobalPhoneNumber(phoneNumber)) {

            Toast.makeText(
                    this,
                    "Please enter a valid phone number.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Save the phone number between app sessions.
        preferences.edit()
                .putString("phone_number", phoneNumber)
                .apply();

        if (hasSmsPermission()) {

            preferences.edit()
                    .putBoolean("sms_enabled", true)
                    .apply();

            Toast.makeText(
                    this,
                    "SMS alerts enabled!",
                    Toast.LENGTH_SHORT
            ).show();

            updateSmsStatus();

        } else {
            // Ask the user for SMS permission.
            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    private boolean hasSmsPermission() {

        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateSmsStatus() {

        boolean enabled = preferences.getBoolean(
                "sms_enabled", false
        );

        if (enabled && hasSmsPermission()) {

            textSmsStatus.setText(
                    "SMS Permission: Enabled"
            );

            textSmsStatus.setTextColor(
                    android.graphics.Color.parseColor("#66754A")
            );

        } else {

            textSmsStatus.setText(
                    "SMS Permission: Not Enabled"
            );

            textSmsStatus.setTextColor(
                    android.graphics.Color.parseColor("#795548")
            );
        }
    }
}
